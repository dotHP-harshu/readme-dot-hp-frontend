import React from "react";
import Button from "./Button";
import LabelPara from "./LabelPara";

function GenerateReopResultRight() {
  const sayHelo = () => {
    console.log("hello");
  };
  return (
    <div className="lg:w-[60%] px-6 sm:w-full max-sm:w-full">
      <div className="px-6 py-4 border-2 border-text-main relative bg-secondary-color space-y-4 before:top-0 before:left-0 before:border-2 before:border-text-main before:absolute before:translate-2 before:w-full before:h-full before:-z-10 ">
        <LabelPara para={"This is the text of selected files."} />
        <div className="button-container space-x-4 ">
          <Button name={"Copy All"} onClick={sayHelo} />
          <Button name={"Download"} onClick={sayHelo} />
        </div>
        <div className="textbox bg-bg-color border-2 border-text-muted p-6 text-base overflow-y-scroll max-h-96 h-96 font-box-text">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt
          ratione non ipsa commodi nemo magni dolorum expedita, consequuntur
          itaque eveniet veniam, quod, voluptatibus modi beatae doloremque id
          est. Tenetur, reiciendis. Lorem ipsum dolor sit amet, consectetur
          adipisicing elit. Incidunt quibusdam ex totam consequatur ea, amet
          nisi hic odio velit tenetur provident deleniti alias labore maxime
          earum rerum nobis atque cum. Lorem ipsum dolor sit amet consectetur
          adipisicing elit. Incidunt ratione non ipsa commodi nemo magni dolorum
          expedita, consequuntur itaque eveniet veniam, quod, voluptatibus modi
          beatae doloremque id est. Tenetur, reiciendis. Lorem ipsum dolor sit
          amet, consectetur adipisicing elit. Incidunt quibusdam ex totam
          consequatur ea, amet nisi hic odio velit tenetur provident deleniti
          alias labore maxime earum rerum nobis atque cum. Lorem ipsum dolor sit
          amet consectetur adipisicing elit. Incidunt ratione non ipsa commodi
          nemo magni dolorum expedita, consequuntur itaque eveniet veniam, quod,
          voluptatibus modi beatae doloremque id est. Tenetur, reiciendis. Lorem
          ipsum dolor sit amet, consectetur adipisicing elit. Incidunt quibusdam
          ex totam consequatur ea, amet nisi hic odio velit tenetur provident
          deleniti alias labore maxime earum rerum nobis atque cum. Lorem ipsum
          dolor sit amet consectetur adipisicing elit. Incidunt ratione non ipsa
          commodi nemo magni dolorum expedita, consequuntur itaque eveniet
          veniam, quod, voluptatibus modi beatae doloremque id est. Tenetur,
          reiciendis. Lorem ipsum dolor sit amet, consectetur adipisicing elit.
          Incidunt quibusdam ex totam consequatur ea, amet nisi hic odio velit
          tenetur provident deleniti alias labore maxime earum rerum nobis atque
          cum.
        </div>
      </div>
    </div>
  );
}

export default GenerateReopResultRight;
