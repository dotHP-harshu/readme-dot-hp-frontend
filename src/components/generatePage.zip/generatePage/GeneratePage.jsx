import React, { useState } from "react";
import InputComponent from "./InputComponent";
import GenerateRepoResult from "./GenerateRepoResult";
import gitDataContext from "../../contexts/gitDataContext";

function GeneratePage() {
  const [isLoadedGitData, setIsLoadedGitData] = useState(false);
  const [gitData, setGitData] = useState(null);
  return (
    <gitDataContext.Provider value={gitData}>
      <section className="py-20">
        <div className="w-full flex justify-center items-center">
          <InputComponent setGitData={setGitData} />
        </div>
        {isLoadedGitData ? (
          <div className="w-full">
            <GenerateRepoResult />
          </div>
        ) : (
          <p>loading...</p>
        )}
      </section>
    </gitDataContext.Provider>
  );
}

export default GeneratePage;
