import React, { useContext } from "react";
import GenerateRepoResultLeft from "./GenerateRepoResultLeft";
import GenerateRepoResultRight from "./GenerateReopResultRight";
import gitDataContext from "../../contexts/gitDataContext";

function GenerateRepoResult() {
  const gitData = useContext(gitDataContext);
  console.log(gitData);
  return (
    <div className="w-full flex lg:flex-row sm:flex-col max-sm:flex-col mt-16 space-y-6">
      <GenerateRepoResultLeft />
      <GenerateRepoResultRight />
    </div>
  );
}

export default GenerateRepoResult;
