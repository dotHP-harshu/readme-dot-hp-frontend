import React, { useState } from "react";
import Button from "./Button";
import LabelPara from "./LabelPara";

function InputComponent({ setGitData }) {
  const [gitRepoUrl, setGitRepoUrl] = useState("");

  const handleGitUrl = async () => {
    try {
      const respose = await fetch(
        "https://readme-dot-hp-backend.vercel.app/api/fetch-git",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            url: gitRepoUrl,
          }),
        }
      );
      if (!respose.ok) return console.log("error on fetching data");
      const data = await respose.json();
      setGitData(data);
      setGitRepoUrl("");
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <div className=" w-fit bg-secondary-color px-6 py-4  border-2 border-text-main relative flex-col items-center justify-center before:top-0 before:left-0 before:border-2 before:border-text-main before:absolute before:translate-2 before:w-full before:h-full before:-z-10">
      <LabelPara para={"Paste or type the URL of git repo."} />
      <div className="space-x-4">
        <input
          onChange={(e) => {
            setGitRepoUrl(e.target.value);
          }}
          value={gitRepoUrl}
          type="text"
          placeholder="https://github.com/username/repo-name"
          className="px-4 py-2 border-text-muted border-2 lg:w-2xl sm:w-lg bg-bg-color"
        />
        <Button name={"Send"} onClick={handleGitUrl} />
      </div>
    </div>
  );
}

export default InputComponent;
