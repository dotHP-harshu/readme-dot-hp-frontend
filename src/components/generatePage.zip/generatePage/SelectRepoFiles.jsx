import React, { useState } from "react";

function SelectRepoFiles() {
  const [filteredArray, setFilteredArray] = useState([]);
  const handleSelectedFile = (e) => {
    let value = e.target.value;
    setFilteredArray((prev) => {
      if (prev.includes(value)) {
        return prev.filter((p) => p != value);
      } else {
        return [...prev, value];
      }
    });
  };
  console.log(filteredArray);
  return (
    <div className="border-text-muted border-2 p-4 bg-bg-color">
      <span className="block">
        <input
          type="checkbox"
          value="filename"
          name="selected-file"
          id="filename"
          className="peer hidden"
          onChange={handleSelectedFile}
        />
        <label
          htmlFor="filename"
          className="select-none cursor-cell peer-checked:line-through peer-checked:text-text-muted"
        >
          filename
        </label>
      </span>
      <span className="block">
        <input
          type="checkbox"
          value="filename2"
          name="selected-file"
          id="filename2"
          className="peer hidden"
          onChange={handleSelectedFile}
        />
        <label
          htmlFor="filename2"
          className="select-none cursor-cell peer-checked:line-through peer-checked:text-text-muted"
        >
          filename2
        </label>
      </span>
      <span className="block">
        <input
          type="checkbox"
          value="filename3"
          name="selected-file"
          id="filename3"
          className="peer hidden"
          onChange={handleSelectedFile}
        />
        <label
          htmlFor="filename3"
          className="select-none cursor-cell peer-checked:line-through peer-checked:text-text-muted"
        >
          filename3
        </label>
      </span>
    </div>
  );
}

export default SelectRepoFiles;
